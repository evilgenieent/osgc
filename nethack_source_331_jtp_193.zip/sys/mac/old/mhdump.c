/* Dump file creator for MPW */

#define NEED_VARARGS

#include ":Include:hack.h"

#pragma dump ":Obj:hack.hdump"


dummy() {}
