/*	SCCS Id: @(#)qt_kde0.h	3.3	1999/11/19	*/
/* Copyright (c) Warwick Allison, 1999. */
/* NetHack may be freely redistributed.  See license for details. */

#ifndef QT_DUMMYKDE
#define QT_DUMMYKDE
class KTopLevelWidget : public QWidget {
        Q_OBJECT
};
#endif
