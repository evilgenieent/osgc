#ifndef _jtp_def_c_
#define _jtp_def_c_

#include "jtp_def.h"

#endif
