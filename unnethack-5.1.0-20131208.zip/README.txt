General information about UnNetHack
===================================

UnNetHack is a fork of NetHack, originally based on NetHack version 3.4.3.

It features more randomness, more levels, more challenges and more fun than
vanilla NetHack.

In a nutshell I would describe UnNetHack as "how NetHack would look today if
the DevTeam didn't stop releasing", following a modern open source project
approach of development.


The project page with detailed information about changes from NetHack, the
development blog, public servers, source code repository and ways to reach the
developer can be found at: http://sourceforge.net/apps/trac/unnethack

For discussion, join the IRC channel #unnethack on irc.freenode.net, post to
rec.games.roguelike.nethack.


 -- Good luck, and happy Hacking
