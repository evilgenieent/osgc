#!/bin/sh
aclocal --install -Im4
autoreconf --verbose --install --symlink --force
