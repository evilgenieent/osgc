
We have moved our version control from svn to git, but not ported all
the release functionality to the new way.

So, no Release Notes, build has just a date (no "real" version), etc.

We hope you enjoy it anyway!


-Clemens + the Colossus developer team
