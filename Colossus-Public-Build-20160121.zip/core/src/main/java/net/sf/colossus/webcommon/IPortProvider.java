/**
 *
 */
package net.sf.colossus.webcommon;


/**
 *
 */
public interface IPortProvider
{
    public abstract int getFreePort(GameInfo gi);
}
