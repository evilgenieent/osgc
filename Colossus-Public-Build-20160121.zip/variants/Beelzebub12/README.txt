README for Beelzebub12 - a variant by Chris Byler and Jay Delanoy

Beelzebub12 is a twelve player form of Beelzebub with a larger
Masterboard and increased creature counts (except for the unique
creatures, which remain unique).

Now with real 12 player support!

For more complete information on Beelzebub and how it differs from
other variants, see the Beelzebub README.
